/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package model;

/**
 *
 * @author jotin
 */

public class Tarefa {

    private String titulo;
    private String descricao;
    private String categoria;
    private String status;
    private String data_Entrega;

    public Tarefa(String titulo, String descricao, String categoria, String status, String data_Entrega) {
        this.titulo = titulo;
        this.descricao = descricao;
        this.categoria = categoria;
        this.status = status;
        this.data_Entrega = data_Entrega;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getDescricao() {
        return descricao;
    }

    public String getCategoria() {
        return categoria;
    }

    public String getStatus() {
        return status;
    }

    public String getData_Entrega() {
        return data_Entrega;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setData_Entrega(String data_Entrega) {
        this.data_Entrega = data_Entrega;
    }
}