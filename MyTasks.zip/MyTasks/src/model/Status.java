/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author jotin
 */

public class Status {
    
    private int idStatus;
    private String descricaoStatus;

    public Status(String descricaoStatus) {
        this.descricaoStatus = descricaoStatus;
    }

    public String getDescricaoStatus() {
        return descricaoStatus;
    }
}
