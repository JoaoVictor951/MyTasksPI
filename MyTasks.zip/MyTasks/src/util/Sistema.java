/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package util;

/**
 *
 * @author jotin
 */

import java.util.ArrayList;
import model.Tarefa;

public class Sistema {
    public static ArrayList<Tarefa> listaTarefas = new ArrayList<>();
    public static java.util.List<model.Usuario> listaUsuarios = new java.util.ArrayList<>();
    public static int usuarioLogadoId;
}