
import view.TelaLogin;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author jotin
 */

public class Main {
    public static void main(String[] args) {
        new TelaLogin().setVisible(true);
    }
}
